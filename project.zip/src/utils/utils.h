#ifndef UTILS_H
#define UTILS_H

#include "../MLP/MLP.h"

void savePredictions(const Matrix& predictions, string filename);

#endif
