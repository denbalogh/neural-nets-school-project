# Simple evaluation utility

```python
python3 evaluate.py -h
python3 evaluate.py ../example_test_predictions.csv ../data/fashion_mnist_test_labels.csv
```
